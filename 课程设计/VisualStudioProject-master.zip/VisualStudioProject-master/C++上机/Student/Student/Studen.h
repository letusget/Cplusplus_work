#pragma once
class CStuff {
public:

};