#define _CRT_SECURE_NO_WARNINGS 1


namespace util
{
	template<typename T>
	T cube(T a)
	{
		//cout << "����ģ��" << endl;
		return a*a;
	}

	template<typename S>
	S square(S a)
	{
		return S();
	}
}

