#include<iostream>

class CGrandpa {
public:
	CGrandpa(){
		std::cout << "Grandpa constructor\n";
	}

	virtual ~CGrandpa() {
		std::cout << "Grandpa destructor\n";
	};
};

class CParent : public CGrandpa {
public:
	CParent() {
		std::cout << "parent constructor\n";
	}
	~CParent() {
		std::cout << "Parent destructor\n";
	}
};

class CChild : public CParent {
public:
	CChild() {
		std::cout << "Child constructor\n";
	}
	~CChild() {
		std::cout << "Child destructor\n";
	}
};

int main() {
	CChild hChild;
	
	return 0;
}